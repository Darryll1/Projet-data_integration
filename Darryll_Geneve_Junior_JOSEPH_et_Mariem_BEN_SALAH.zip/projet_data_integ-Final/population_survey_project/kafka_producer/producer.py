from kafka import KafkaProducer
import json
import time
import csv

KAFKA_BROKER = 'localhost:9092'
TOPIC = 'population_data'

# Création du producteur Kafka
producer = KafkaProducer(
    bootstrap_servers=KAFKA_BROKER,
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

def read_population_data():
   
    data = []
    with open('total-population.csv', 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)
    return data

 def send_to_kafka():
    """Envoie les données à Kafka une par une."""
    while True:
        data_batch = read_population_data()
        for record in data_batch:
            producer.send(TOPIC, value=record)
            print(f"Sent record: {record}")
        time.sleep(10)           

if __name__ == "__main__":
    send_to_kafka()
