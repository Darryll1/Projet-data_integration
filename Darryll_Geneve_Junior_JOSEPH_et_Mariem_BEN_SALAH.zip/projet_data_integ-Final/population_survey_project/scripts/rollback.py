from pyspark.sql import SparkSession

# Initialiser une session Spark
spark = SparkSession.builder \
    .appName("Rollback") \
    .config("spark.jars", "sqlite-jdbc.jar") \  # Chemin vers le fichier .jar du pilote SQLite JDBC
    .getOrCreate()

# Charger les données depuis la base SQLite
db_path = "ma_base_de_donnees7.db"  # Remplacez par le chemin réel
table_name = "ma_table"  # Nom de la table à charger

# Lire les données via JDBC
previous_data = spark.read.format("jdbc") \
    .option("url", f"jdbc:sqlite:{db_path}") \
    .option("dbtable", table_name) \
    .option("driver", "org.sqlite.JDBC") \
    .load()

# Sauvegarder les données restaurées
output_db_path = "output_database.db"  # Chemin pour sauvegarder
previous_data.write.format("jdbc") \
    .option("url", f"jdbc:sqlite:{output_db_path}") \
    .option("dbtable", table_name) \
    .option("driver", "org.sqlite.JDBC") \
    .mode("overwrite") \
    .save()

print("Data rolled back to the previous version.")
