from kafka import KafkaConsumer
import json
import sqlite3
import json
import pandas as pd
from tabulate import tabulate
from sqlalchemy import create_engine

KAFKA_BROKER = 'localhost:9092'
TOPIC = 'population_data'
# Création du consommateur Kafka
consumer = KafkaConsumer(
   TOPIC,
   bootstrap_servers=KAFKA_BROKER,
   auto_offset_reset='earliest',  # Lire depuis le début des messages si c'est la première fois
   enable_auto_commit=True,
   value_deserializer=lambda v: json.loads(v.decode('utf-8'))  # Désérialiser les messages JSON
)
print(f"Écoute des messages sur le topic '{TOPIC}'...")
# Lecture des messages
for message in consumer:
   # message.value contient les données sérialisées par le producteur
   json_data = message.value
   # Pass an index when creating the DataFrame
   json_df = pd.DataFrame([json_data])
   json_df['Id'] = json_df['Id'].astype(int)
   # Étape 2 : Charger le fichier CSV
   csv_file_path = "../hdfs_data/all_data_joined.csv"  # Remplacez par le chemin réel du fichier
   csv_df = pd.read_csv(csv_file_path)
   csv_df['aggregate_income_Id'] = csv_df['aggregate_income_Id'].astype(int)
   merged_df = pd.merge(
     json_df,
     csv_df,
     left_on="Id",
     right_on="aggregate_income_Id",
     how="inner"  # Utilisez 'inner' pour une jointure interne
     )
   # Connexion à la base de données SQLite
   conn = sqlite3.connect('ma_base_de_donnees8.db')
   # Insérer les données dans la table
   merged_df.to_sql('ma_table', conn, if_exists='append', index=False)
# Afficher la table en utilisant une requête SQL
query = "SELECT * FROM ma_table"
table_df = pd.read_sql_query(query, conn)
print(tabulate(table_df, headers='keys', tablefmt='psql'))
# Fermeture de la connexion
conn.close()